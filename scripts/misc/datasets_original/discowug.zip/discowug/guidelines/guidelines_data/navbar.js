

//var list = document.getElementsByClassName("nav_links");
//
//
//for ( var j = 0 ; j < list.length ; ++j ) {
//    var links = list.children;
//    for (var i = 0; i < links.length; i++) {
//      links[i].addEventListener("click", function() {
//      var current = document.getElementsByClassName("active");
//      console.log(current);
//      current[0].className = current[0].className.replace(" active", "");
//      this.className += " active";
//      });
//}
//
//}
//
